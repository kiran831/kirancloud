angular.module("myApp")
	.controller("aboutController", function($scope){
		$scope.message = "You are on about controller";
	})