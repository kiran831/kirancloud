angular.module("myApp")
	.controller("contactController", function($scope){
		$scope.message = "You are on contact controller";
	})